
import com.sun.xml.internal.messaging.saaj.util.ByteInputStream;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author meherzad
 */
public class blobType {

    private String DATABASEDRIVER = "com.mysql.jdbc.Driver";
    private String DATABASEURL = "jdbc:mysql://localhost:3306/sample?user=root&password=12345";
    private Connection con;

    public blobType() {
        /*        ResourceBundle rb = ResourceBundle.getBundle("Repo.Config");
         DATABASEDRIVER = rb.getString("DatabaseVendorDriver");
         DATABASEURL = rb.getString("DatabaseURL");*/
    }

    /**
     * Connect with the database
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public void connect() throws ClassNotFoundException, SQLException {
        Class.forName(DATABASEDRIVER);
        con = DriverManager.getConnection(DATABASEURL);
    }

    /**
     * Disconnect with database
     *
     * @throws SQLException
     */
    public void disConnect() throws SQLException {
        con.close();
    }

    public boolean blobInsert() {
        boolean result;
        try {
            connect();
            PreparedStatement pst = con.prepareStatement("Insert into blolType (blobData) values (?);");
            String str = "Hi meherzad here.";
            byte[] data = str.getBytes();
            java.io.InputStream is = new ByteArrayInputStream(data);
            pst.setBinaryStream(1, is);
            pst.executeUpdate();
            result = true;
            System.out.println("-------------------------");
        } catch (Exception e) {
            e.printStackTrace();
            result = false;
        } finally {
            try {
                disConnect();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;

    }

    public boolean readBlob() {
        boolean result;
        try {
            connect();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from blolType;");
            rs.next();
            InputStream is = rs.getBinaryStream("blobData");
            java.io.BufferedReader in = new BufferedReader(new java.io.InputStreamReader(is));
            String total = "";
            String str1;
            while ((str1 = in.readLine()) != null) {
                total += str1;
            }
            System.out.println("000000000000000----- > " + total);
            is.close();
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
            result = false;
        } finally {
            try {
                disConnect();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public static void main(String args[]) {
        blobType obj = new blobType();
        obj.blobInsert();
        obj.readBlob();
    }
}
